#!/bin/bash
# create multiresolution windows icon
ICON_DST=../../src/qt/res/icons/BitDollars.ico

convert ../../src/qt/res/icons/BitDollars-16.png ../../src/qt/res/icons/BitDollars-32.png ../../src/qt/res/icons/BitDollars-48.png ${ICON_DST}
